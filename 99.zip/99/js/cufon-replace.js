Cufon.replace('h3', { fontFamily: 'NewsGoth bold', hover:true });
Cufon.replace('.menu li:not(.active) a', { fontFamily: 'Vegur', textShadow: '1px 1px rgba(0, 0, 0, 0.2)', hover: {textShadow: 'none'} });
Cufon.replace('.menu li.active a, .list-services a, .box a', { fontFamily: 'Vegur'});
Cufon.replace('h4', { fontFamily: 'NewsGoth', hover:true });
Cufon.replace('h4 em', { fontFamily: 'NewsGoth Lt BT', hover:true });
