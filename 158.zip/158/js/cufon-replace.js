Cufon.replace('h1, #header h2, .button', { fontFamily: 'Kozuka Gothic Pro OpenType', textShadow: '#336600 1px 1px'  });
Cufon.replace('h2, h3', { fontFamily: 'Kozuka Gothic Pro OpenType'});