Cufon.replace('.slog', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.menu li a', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.b1', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.b2', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('.b3', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('h3', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('h3 strong', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('.numb', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('h2', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('.button-2', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.tdate-1', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('h4', { fontFamily: 'Open Sans Semibold', hover:true });
Cufon.replace('.footer-logo', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.footer-logo strong', { fontFamily: 'Open Sans Light', hover:true });
Cufon.replace('.phone', { fontFamily: 'Open Sans', hover:true });

