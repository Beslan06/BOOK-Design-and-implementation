Cufon.replace('.menu li a, .banner em', { fontFamily: 'Kozuka Gothic Pro OpenType', hover:true });
Cufon.replace('.banner > strong, h3, .tdate-1 strong, h4, .circle', { fontFamily: 'Kozuka Gothic Pro OpenType 900', hover:true });
Cufon.replace('.tdate-1, .text-1', { fontFamily: 'Kozuka Gothic Pro OpenType 700', hover:true });
Cufon.replace('.title-1', { fontFamily: 'Kozuka Gothic Pro OpenType 500', hover:true });
